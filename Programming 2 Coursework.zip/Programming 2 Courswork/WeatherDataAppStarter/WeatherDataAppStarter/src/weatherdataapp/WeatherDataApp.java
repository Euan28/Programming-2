/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package weatherdataapp;

import controllers.WeatherDataController;

    public class WeatherDataApp {

        public static void run() 
        {System.out.println("Weather App\n===========\n\n");
            WeatherDataController weatherController = new WeatherDataController();  
            weatherController.run();
            System.out.println("Thank you for using Weather App. Good bye.\n");}

        public static void main(String[] args) 
        {WeatherDataApp weatherApp = new WeatherDataApp();
            weatherApp.run();}
    }
