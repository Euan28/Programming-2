/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import daos.DAOTextImpl;
import model.City;

    public class Repository implements RepositoryInterface 
        {private List<City> items;  

            public Repository() 
                {this.items = new ArrayList<>();}

            public Repository(List<City> items) 
                {this.items = items;}

            public Repository(String filename) 
                {this();
                    DAOTextImpl dao = new DAOTextImpl();
                    this.items = dao.load(filename).getItems();}

            @Override
                public List<City> getItems() 
                {return this.items;}

            @Override
                public void setItems(List<City> items) 
                {this.items = items;}

            @Override
                public void add(City item) 
                {this.items.add(item);}

            @Override
                public void remove(int id) 
                {Predicate<City> predicate = e->e.getId() == id;       
                this.items.removeIf(predicate);}

            @Override
                public City getItem(int id) 
                {for (City item:this.items) 
                {if (item.getId() == id)
                return item;}
                return null;}

            @Override
                public String toString() 
                {return "\nItems: " + this.items;}    

            public String toString(char delimiter) 
                {String output = "";
                for (City city : this.items)
                {output += city.toString(delimiter);}

            System.out.println(output);
            return output;}


            @Override
                public void store(String filename) {
                    DAOTextImpl dao = new DAOTextImpl();
                    dao.store(filename, this);
                    // create dao and execute store    
        }        
    }
