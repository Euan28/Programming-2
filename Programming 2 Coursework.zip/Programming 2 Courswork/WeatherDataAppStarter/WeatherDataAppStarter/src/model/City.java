/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

    public class City implements Comparable<City> 
       {private final int id;
        private String cityName;
        private String country;
        private List<YearData> yearDataCollection;

        private static int lastIdAllocated = 0;

        static final char EOLN='\n';       
        static final String QUOTE="\""; 

        public City() 
           {this.id = ++lastIdAllocated;
            this.cityName = "TBC";
            this.country = "TBC";
            this.yearDataCollection = new ArrayList<>();}

        public City(String cityName, String country) 
           {this.id = ++lastIdAllocated;
            this.cityName = cityName;
            this.country = country;
            this.yearDataCollection = new ArrayList<>();}
        

        public City(String cityName, String country, List<YearData> yearDataCollection) 
           {this.id = ++lastIdAllocated;        
            this.cityName = cityName;
            this.country = country;
            this.yearDataCollection = yearDataCollection;}
        

        public City(int id, String cityName, String country, List<YearData> yearDataCollection) 
            {this.id = id;
            this.cityName = cityName;
            this.country = country;
            this.yearDataCollection = yearDataCollection;
            if (id > City.lastIdAllocated)
                City.lastIdAllocated = id;}          
        

        public int getId() 
            {return this.id;}
        

        public String getCityName () 
            {return this.cityName;}
        

        public void setCityName(String cityName) 
            {this.cityName = cityName;}
        

        public String getCountry() 
            {return this.country;}
        

        public void setCountry(String country) 
            {this.country = country;}
        

        public List<YearData> getYearDataCollection() 
            {return this.yearDataCollection;}
        

        public void setYearData(List<YearData> yearDataCollection) 
            {this.yearDataCollection = yearDataCollection;}
        

        public void addYearData(YearData yearData) 
            {this.yearDataCollection.add(yearData);}
        
        // Methods required: getters, setters, add, hashCode, equals, compareTo, comparator

        @Override
        public String toString() 
            {String strYearData = "";
                for (YearData yearData : this.yearDataCollection) 
                 {strYearData += yearData.toString();}
            
                       return EOLN + 
                           "(" + id + ") City: " + 
                            cityName + 
                            " (Country: " 
                            + country + ")" 
                            + ((strYearData.length() > 0) ? strYearData : "\n[ empty data ]") + EOLN;}
        

        public String toString(char delimiter) 
            {String str = Integer.toString(this.id) + delimiter +
                                     QUOTE + this.cityName + QUOTE + delimiter +
                                     QUOTE + this.country + QUOTE + delimiter +
                                     Integer.toString(this.yearDataCollection.size()) + EOLN;
                for (YearData yearData : this.yearDataCollection) 
                    {str += yearData.toString(delimiter);}
            
            return str;}
        

        @Override
            public int hashCode() 
                   {final int prime = 37;
                    int result = 1;
                    result = prime * result + ((cityName == null) ? 0 : cityName.hashCode());
                    result = prime * result + ((country == null) ? 0 : country.hashCode());
                    result = prime * result + id;
                    result = prime * result + ((yearDataCollection == null) ? 0 : yearDataCollection.hashCode());
                    return result;}
            

            @Override
            public boolean equals(Object obj) 
                   {if (this == obj)
                            return true;
                    if (obj == null)
                            return false;
                    if (getClass() != obj.getClass())
                            return false;
                    City other = (City) obj;
                    if (cityName == null) {
                            if (other.cityName != null)
                                    return false;
                    } else if (!cityName.equals(other.cityName))
                            return false;
                    if (country == null) {
                            if (other.country != null)
                                    return false;
                    } else if (!country.equals(other.country))
                            return false;
                    if (id != other.id)
                            return false;
                    if (yearDataCollection == null) {
                            if (other.yearDataCollection != null)
                                    return false;
                    } else if (!yearDataCollection.equals(other.yearDataCollection))
                            return false;
                    return true;}
            

            public static Comparator<City> compareCityName = new Comparator<City>() {
                @Override
                public int compare(City c1, City c2)
                
                  {String cityName1 = c1.cityName;
                   String cityName2 = c2.cityName;
                   return cityName1.compareTo(cityName2);}
                
             };

            public int compareTo(City compareCity) 
                {return Integer.compare(this.id, compareCity.id);}
            

    }