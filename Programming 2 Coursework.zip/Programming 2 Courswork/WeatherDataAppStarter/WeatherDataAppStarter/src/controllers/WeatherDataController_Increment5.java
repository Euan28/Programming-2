/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package controllers;

import java.util.Set;
import java.util.TreeSet;

import helpers.InputHelper;
import repositories.Repository;

import model.City;
import model.YearData;

    public class WeatherDataController_Increment5 
       {private final Repository repository;
        private final static InputHelper inputHelper = new InputHelper();

        public WeatherDataController_Increment5() 
            {this.repository = new Repository("out.txt");}


        public void run() {
            boolean finished = false;

            do {
                char choice = displayMenu();
                switch (choice) {
                    case 'A': 
                        addCity();
                        break;
                    case 'B':  
                        addYearData();
                        break;
                    case 'C': 
                        listCountryCityWeatherDataInCityNameOrder();
                        break;                    
                    case 'D': 
                        listCityAverages();
                        break;
                    case 'Q': 
                        finished = true;
                }
            } while (!finished);
        }

        private char displayMenu() {
            listCityWeatherDataInCityIdOrder();

            System.out.print("\nA. Add City");
            System.out.print("\tB. Add new year data");        
            System.out.print("\tC. List Country Data In City Name Order");
            System.out.print("\tD. List City Average Data");       
            System.out.print("\tQ. Quit\n");         
            return inputHelper.readCharacter("Enter choice", "ABCDQ");
        }    

        private void addCity() {
            System.out.format("\033[31m%s\033[0m%n", "Add City");
            System.out.format("\033[31m%s\033[0m%n", "========");    

            String cityName = inputHelper.readString("Enter the city name, please");
            String country = inputHelper.readString("Enter the country name, please");

            City city = new City(cityName, country);
            this.repository.add(city);
            System.out.println(city.toString());
        }

        private void addYearData() {        
            System.out.format("\033[31m%s\033[0m%n", "Add Year Data");
            System.out.format("\033[31m%s\033[0m%n", "=============");   

            City selectedCity = null;
            while(selectedCity == null) {
                    int cityId = inputHelper.readInt("Enter City ID");
                    selectedCity = repository.getItem(cityId);
            }
            System.out.println("Selected city\n=============\n" + selectedCity);
            String year = inputHelper.readString("Enter year");        
            float precipitation = inputHelper.readFloat("Enter the precipitation please");
            int maxTemp = inputHelper.readInt("Enter the max temperature please");
            int minTemp = inputHelper.readInt("Enter the min temperature please");
            int windSpeed = inputHelper.readInt("Enter the wind speed please");
            String windDirection = inputHelper.readString("Enter the wind direction please");
            YearData yearData = new YearData(year, precipitation, maxTemp, minTemp, windSpeed, windDirection);
            selectedCity.addYearData(yearData);
            System.out.println(selectedCity.toString());
        }    


        private void listCountryCityWeatherDataInCityNameOrder() {        
            System.out.format("\033[31m%s\033[0m%n", "City Name Order");
            System.out.format("\033[31m%s\033[0m%n", "===============");

                    Set<City> sortedSet = new TreeSet<City>(City.compareCityName);
                    sortedSet.addAll(this.repository.getItems());     
                    for (City city : sortedSet) {
                            System.out.print(city);
                    }
                System.out.println();
        }    

        private void listCityAverages() {
            System.out.format("\033[31m%s\033[0m%n", "City Average Data");
            System.out.format("\033[31m%s\033[0m%n", "================="); 

            for (City city : this.repository.getItems()) {
                    float avgPrecipitation = 0;
                    int avgMaxTemp = 0;
                    int avgMinTemp = 0;
                    int avgWindSpeed = 0;
                    for (YearData year : city.getYearDataCollection()) {
                            avgPrecipitation += year.getPrecipitation();
                            avgMaxTemp += year.getMaxTemp();
                            avgMinTemp += year.getMinTemp();
                            avgWindSpeed += year.getWindSpeed();
                    }
                    int amount = city.getYearDataCollection().size();
                    avgPrecipitation /= amount;
                    avgMaxTemp /= amount;
                    avgMinTemp /= amount;
                    avgWindSpeed /= amount;        			
                    System.out.print(city);
                    System.out.println("- avg: precipitation=" + avgPrecipitation + " | maxTemp=" + avgMaxTemp + " | minTemp=" + avgMinTemp + " | windSpeed=" + avgWindSpeed);
                    }
                    System.out.println();
        }    

        private void listCityWeatherDataInCityIdOrder() {        
            System.out.format("\033[31m%s\033[0m%n", "City Id Order");
            System.out.format("\033[31m%s\033[0m%n", "============="); 
                  this.repository.getItems().stream().sorted(City::compareTo).forEach(city -> {
                    System.out.print(city.toString());
            });
        }     
    }

