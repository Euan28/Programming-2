/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package controllers;

import helpers.InputHelper;
import repositories.Repository;

import model.City;

public class WeatherDataController_Increment1 
    {private final Repository repository;
    
    public WeatherDataController_Increment1() 
        {this.repository = new Repository("weatherdata17August.txt");}
    
   
    public void run() 
        {boolean finished = false;
        
        do 
           {char choice = displayMenu();
            switch (choice) {
                case 'A': 
                    addCity();
                    break;
                case 'B':  
                    addYearData();
                    break;
                case 'C': 
                    listCountryCityWeatherDataInCityNameOrder();
                    break;                    
                case 'D': 
                    listCityAverages();
                    break;
                case 'Q': 
                    finished = true;
            }
        } while (!finished);}
    
    
    private char displayMenu() {
        listCityWeatherDataInCityIdOrder();
        InputHelper inputHelper = new InputHelper();
        System.out.print("\nA. Add City");
        System.out.print("\tB. Add new year data");        
        System.out.print("\tC. List Country Data In City Name Order");
        System.out.print("\tD. List City Average Data");       
        System.out.print("\tQ. Quit\n");         
        return inputHelper.readCharacter("Enter choice", "ABCDQ");
    }    
    
    private void addCity() {
        System.out.format("\033[31m%s\033[0m%n", "Add City");
        System.out.format("\033[31m%s\033[0m%n", "========"); 
        
       
    }
    
    private void addYearData() {        
        System.out.format("\033[31m%s\033[0m%n", "Add Year Data");
        System.out.format("\033[31m%s\033[0m%n", "=============");   
    }    
      

    private void listCountryCityWeatherDataInCityNameOrder() {        
        System.out.format("\033[31m%s\033[0m%n", "City Name Order");
        System.out.format("\033[31m%s\033[0m%n", "===============");

    }    
    
    private void listCityAverages() {
        System.out.format("\033[31m%s\033[0m%n", "City Average Data");
        System.out.format("\033[31m%s\033[0m%n", "================="); 
    }    
    
    private void listCityWeatherDataInCityIdOrder() {        
        System.out.format("\033[31m%s\033[0m%n", "City Id Order");
        System.out.format("\033[31m%s\033[0m%n", "============="); 
              this.repository.getItems().stream().sorted(City::compareTo).forEach(city -> {
        	System.out.print(city.toString());
        });
    }     
}

