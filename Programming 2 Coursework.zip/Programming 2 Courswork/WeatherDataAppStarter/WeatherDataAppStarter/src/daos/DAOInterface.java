/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package daos;

import repositories.Repository;

public interface DAOInterface 

   {public Repository load(String filename);
    public void store(String filename, Repository repository);}

