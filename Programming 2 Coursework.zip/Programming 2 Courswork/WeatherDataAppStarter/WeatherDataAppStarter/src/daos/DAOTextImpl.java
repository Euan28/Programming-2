/*
Euan Martin
Programming Coursework 2018
Computing BSc (Hons) - Caledonian University
 */
package daos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import model.City;
import model.YearData;
import repositories.Repository;

    public class DAOTextImpl implements DAOInterface 

        {static final char DELIMITER = ',';

            @Override
            public Repository load(String filename) 
                   {Repository repository = new Repository();
                    try (BufferedReader br = new BufferedReader(new FileReader(filename))) 
                           {String[] temp;
                            String line = br.readLine();
                            while (line != null) 
                                    {temp = line.split(Character.toString(DELIMITER));
                                    int cityId = Integer.parseInt(temp[0]);
                                    String cityName = stripQuotes(temp[1]);
                                    String country = stripQuotes(temp[2]);
                                    int collectionLength = Integer.parseInt(temp[3]);
                                    City city = new City(cityId, cityName, country, new ArrayList<>());
                                    for (int i = 0; i < collectionLength; i++) 
                                            {line = br.readLine();
                                            temp = line.split(Character.toString(DELIMITER));

                                            String year = stripQuotes(temp[0]);
                                            float precipitation = Float.parseFloat(temp[1]);
                                            int maxTemp = Integer.parseInt(temp[2]);
                                            int minTemp = Integer.parseInt(temp[3]);
                                            int windSpeed = Integer.parseInt(temp[4]);
                                            String windDirection = stripQuotes(temp[5]);
                                            city.addYearData(new YearData(year, precipitation, maxTemp, minTemp, windSpeed, windDirection));}

                                    repository.add(city);
                                    line = br.readLine();}

                    } catch (FileNotFoundException e) 
                        {e.printStackTrace();}
                     catch (IOException e) 
                         {e.printStackTrace();}

                    return repository;}


            @Override
        public void store(String filename, Repository repository) 

            {try (PrintWriter output = new PrintWriter(filename)) 
                           {output.print(repository.toString(DELIMITER));		
                            output.close();}
                      catch (FileNotFoundException e) 
                            // TODO Auto-generated catch block
                            {e.printStackTrace();}

            }

            private String stripQuotes(String str) 
                {return str.substring(1, str.length()-1);}

    }

